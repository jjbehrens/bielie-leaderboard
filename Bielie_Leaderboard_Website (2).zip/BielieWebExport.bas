Attribute VB_Name = "BielieWebExport"
'=====================================================================
' Bielie Leaderboard 2026 - website export
'
' 1. Writes data.js (Day 1 and Day 2 scores from the Players table) into the folder
'    that holds leaderboard.html - for the projector/TV laptop.
' 2. Uploads the same data.js to your GitHub repository so the online
'    leaderboard (GitHub Pages) updates for everyone's phones.
'
' Macros:
'   StartWebExport  - export every EXPORT_SECONDS; upload to GitHub when
'                     scores change (at most once per PUSH_MIN_SECONDS)
'   StopWebExport   - stop the automatic export
'   ExportWebData   - write data.js once (local only)
'   PushWebNow      - write data.js and upload it to GitHub now, with a
'                     message telling you whether it worked (use to test)
'
' This module does not touch your existing DisplayRotation macros.
'=====================================================================
Option Explicit

' ---------- SETTINGS ----------
' Folder that holds leaderboard.html. Leave "" to use the workbook's own folder.
Public Const WEB_FOLDER As String = ""

' Your GitHub user name and repository name (leave GITHUB_OWNER "" to switch uploads off)
Public Const GITHUB_OWNER As String = "jjbehrens"
Public Const GITHUB_REPO As String = "bielie-leaderboard"
Public Const GITHUB_BRANCH As String = "main"

' The access token is NOT stored in the workbook. Put it in a text file called
' github-token.txt in the same folder as the workbook (one line, nothing else).
Public Const TOKEN_FILE As String = "github-token.txt"

Public Const EXPORT_SECONDS As Long = 10
Public Const PUSH_MIN_SECONDS As Long = 60
' ------------------------------

Private mNextRun As Date
Private mRunning As Boolean
Private mLastPushedBody As String
Private mLastPushTime As Date
Private mLastPushMsg As String
Private mTokenPath As String

Public Sub StartWebExport()
    mRunning = True
    WebExportTick
End Sub

Public Sub StopWebExport()
    mRunning = False
    On Error Resume Next
    Application.OnTime mNextRun, "BielieWebExport.WebExportTick", , False
    On Error GoTo 0
    Application.StatusBar = False
End Sub

Public Sub WebExportTick()
    If Not mRunning Then Exit Sub
    Dim body As String
    On Error Resume Next
    body = ExportWebData(True)
    If GitHubEnabled() And body <> "" And body <> mLastPushedBody Then
        If mLastPushTime = 0 Or (Now - mLastPushTime) * 86400# >= PUSH_MIN_SECONDS Then
            If PushToGitHub(BuildJs(body)) Then mLastPushedBody = body
            mLastPushTime = Now
        End If
    End If
    On Error GoTo 0
    Application.StatusBar = "Website export running  |  local " & Format(Now, "hh:nn:ss") & _
        IIf(GitHubEnabled(), "  |  online: " & mLastPushMsg, "") & "  |  StopWebExport to stop"
    mNextRun = Now + TimeSerial(0, 0, EXPORT_SECONDS)
    Application.OnTime mNextRun, "BielieWebExport.WebExportTick"
End Sub

Public Sub PushWebNow()
    Dim body As String
    body = ExportWebData(True)
    If Not GitHubEnabled() Then
        MsgBox "data.js written to " & OutputFolder() & vbCrLf & vbCrLf & _
               "GitHub upload is off: fill in GITHUB_OWNER at the top of the BielieWebExport module.", vbExclamation
        Exit Sub
    End If
    If PushToGitHub(BuildJs(body)) Then
        mLastPushedBody = body: mLastPushTime = Now
        MsgBox "Uploaded to GitHub (token: " & mTokenPath & ")." & vbCrLf & "The online leaderboard updates in about a minute:" & vbCrLf & _
               "https://" & LCase$(GITHUB_OWNER) & ".github.io/" & GITHUB_REPO & "/", vbInformation
    Else
        MsgBox "Upload to GitHub failed:" & vbCrLf & vbCrLf & mLastPushMsg & vbCrLf & vbCrLf & _
               "Token file used: " & IIf(mTokenPath = "", "(none found)", mTokenPath), vbExclamation
    End If
End Sub

' Writes data.js locally and returns the player rows (used to detect changes).
Public Function ExportWebData(Optional ByVal quiet As Boolean = False) As String
    Dim body As String, folder As String
    body = PlayersBody()
    If body = "" Then Exit Function
    folder = OutputFolder()
    WriteUtf8 folder & Application.PathSeparator & "data.js", BuildJs(body)
    If Not quiet Then Application.StatusBar = "Website updated " & Format(Now, "hh:nn:ss") & "  ->  " & folder
    ExportWebData = body
End Function

Private Function BuildJs(ByVal body As String) As String
    BuildJs = "// Bielie Leaderboard 2026 - Day 1 data. Written by the ExportWebData macro." & vbLf & _
              "// Columns: Div, Surname, Name, CH, D1 Gross, D1 Nett, D1 Points, D2 Gross, D2 Nett, D2 Points" & vbLf & _
              "window.BIELIE_DATA = {""updated"":""" & Format(Now, "hh:nn") & """,""players"":[" & vbLf & _
              body & "]};" & vbLf
End Function

Private Function PlayersBody() As String
    Dim lo As ListObject, data As Variant, r As Long, js As String
    Dim cDiv As Long, cVan As Long, cNaam As Long, cCH As Long
    Dim cG1 As Long, cN1 As Long, cP1 As Long
    Dim cG2 As Long, cN2 As Long, cP2 As Long

    Set lo = ThisWorkbook.Worksheets("Players").ListObjects("Players")
    If lo.DataBodyRange Is Nothing Then Exit Function
    cDiv = lo.ListColumns("DIV").Index
    cVan = lo.ListColumns("VAN").Index
    cNaam = lo.ListColumns("NAAM").Index
    cCH = lo.ListColumns("CH").Index
    cG1 = lo.ListColumns("D1 Gross").Index
    cN1 = lo.ListColumns("D1 Nett").Index
    cP1 = lo.ListColumns("D1 Points").Index
    cG2 = lo.ListColumns("D2 Gross").Index
    cN2 = lo.ListColumns("D2 Nett").Index
    cP2 = lo.ListColumns("D2 Points").Index
    data = lo.DataBodyRange.Value2

    For r = 1 To UBound(data, 1)
        If Trim$(CStr(data(r, cDiv))) <> "" Then
            js = js & "[" & JsStr(UCase$(Trim$(CStr(data(r, cDiv))))) & "," & _
                 JsStr(Trim$(CStr(data(r, cVan)))) & "," & _
                 JsStr(Trim$(CStr(data(r, cNaam)))) & "," & _
                 JsNum(data(r, cCH)) & "," & JsNum(data(r, cG1)) & "," & _
                 JsNum(data(r, cN1)) & "," & JsNum(data(r, cP1)) & "," & _
                 JsNum(data(r, cG2)) & "," & JsNum(data(r, cN2)) & "," & JsNum(data(r, cP2)) & "]," & vbLf
        End If
    Next r
    If Right$(js, 2) = "," & vbLf Then js = Left$(js, Len(js) - 2) & vbLf
    PlayersBody = js
End Function

'---------------- GitHub upload ----------------
Private Function GitHubEnabled() As Boolean
    GitHubEnabled = (GITHUB_OWNER <> "" And GITHUB_OWNER <> "YOUR-GITHUB-USERNAME")
End Function

Private Function PushToGitHub(ByVal content As String) As Boolean
    Dim token As String, url As String, http As Object, sha As String, payload As String
    token = ReadToken()
    If token = "" Then
        mLastPushMsg = "no token file found - save the token as " & ThisWorkbook.Path & Application.PathSeparator & TOKEN_FILE
        Exit Function
    End If
    If Left$(token, 4) <> "ghp_" And Left$(token, 11) <> "github_pat_" Then
        mLastPushMsg = "the token in " & mTokenPath & " doesn't look like a GitHub token (should start with github_pat_)"
        Exit Function
    End If

    url = "https://api.github.com/repos/" & GITHUB_OWNER & "/" & GITHUB_REPO & "/contents/data.js"
    On Error GoTo Failed
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.setTimeouts 5000, 5000, 10000, 15000

    ' 1. current file version (GitHub needs its "sha" to replace it)
    http.Open "GET", url & "?ref=" & GITHUB_BRANCH, False
    SetHeaders http, token
    http.send
    If http.Status = 200 Then
        sha = JsonValue(http.responseText, "sha")
    ElseIf http.Status <> 404 Then
        mLastPushMsg = ExplainStatus(http.Status) & GitHubSays(http): Exit Function
    End If

    ' 2. upload the new version
    payload = "{""message"":""Scores " & Format(Now, "hh:nn:ss") & """,""branch"":""" & GITHUB_BRANCH & """," & _
              """content"":""" & Base64Utf8(content) & """" & IIf(sha <> "", ",""sha"":""" & sha & """", "") & "}"
    http.Open "PUT", url, False
    SetHeaders http, token
    http.setRequestHeader "Content-Type", "application/json"
    http.send payload
    If http.Status = 200 Or http.Status = 201 Then
        mLastPushMsg = "uploaded " & Format(Now, "hh:nn:ss")
        PushToGitHub = True
    Else
        mLastPushMsg = ExplainStatus(http.Status) & GitHubSays(http)
    End If
    Exit Function
Failed:
    mLastPushMsg = "no internet connection? (" & Err.Description & ")"
End Function

Private Function GitHubSays(http As Object) As String
    Dim m As String
    On Error Resume Next
    m = JsonValue(http.responseText, "message")
    If m <> "" Then GitHubSays = "  [GitHub: " & m & "]"
End Function

Private Sub SetHeaders(http As Object, ByVal token As String)
    http.setRequestHeader "Authorization", "Bearer " & token
    http.setRequestHeader "Accept", "application/vnd.github+json"
    http.setRequestHeader "X-GitHub-Api-Version", "2022-11-28"
    http.setRequestHeader "User-Agent", "Bielie-Leaderboard-Excel"
End Sub

Private Function ExplainStatus(ByVal s As Long) As String
    Select Case s
        Case 401: ExplainStatus = "token rejected (401) - check github-token.txt / token expiry"
        Case 403: ExplainStatus = "not allowed (403) - token needs Contents: Read and write on this repo"
        Case 404: ExplainStatus = "repo not found (404) - check GITHUB_OWNER / GITHUB_REPO and token repo access"
        Case 409: ExplainStatus = "conflict (409) - will retry"
        Case Else: ExplainStatus = "GitHub error " & s
    End Select
End Function

Private Function ReadToken() As String
    Dim p As String, f As Integer, s As String, cand As Variant
    For Each cand In Array(ThisWorkbook.Path, OutputFolder())
        If LCase$(Left$(cand, 4)) <> "http" Then
            p = cand & Application.PathSeparator & TOKEN_FILE
            If Dir(p) <> "" Then Exit For
            ' Windows hides ".txt", so the file is often saved as github-token.txt.txt
            p = p & ".txt"
            If Dir(p) <> "" Then Exit For
            p = ""
        End If
    Next cand
    mTokenPath = p
    If p = "" Then Exit Function
    f = FreeFile
    Open p For Input As #f
    If Not EOF(f) Then Line Input #f, s
    Close #f
    ReadToken = Trim$(Replace(s, vbTab, ""))
End Function

Private Function JsonValue(ByVal json As String, ByVal key As String) As String
    Dim i As Long, j As Long
    i = InStr(1, json, """" & key & """:""")
    If i = 0 Then Exit Function
    i = i + Len(key) + 4
    j = InStr(i, json, """")
    JsonValue = Mid$(json, i, j - i)
End Function

Private Function Base64Utf8(ByVal text As String) As String
    Dim st As Object, bytes() As Byte, el As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.WriteText text
    st.Position = 0: st.Type = 1: st.Position = 3   ' skip the UTF-8 byte-order mark
    bytes = st.Read
    st.Close
    Set el = CreateObject("MSXML2.DOMDocument.6.0").createElement("b64")
    el.DataType = "bin.base64"
    el.nodeTypedValue = bytes
    Base64Utf8 = Replace(Replace(el.text, vbLf, ""), vbCr, "")
End Function

'---------------- local file helpers ----------------
Private Function OutputFolder() As String
    Dim p As String
    p = WEB_FOLDER
    If p = "" Then p = ThisWorkbook.Path
    ' Workbooks opened from OneDrive/SharePoint report a web address as their path.
    If LCase$(Left$(p, 4)) = "http" Or p = "" Then
        p = Environ$("USERPROFILE") & "\Documents\BielieWebsite"
        If Dir(p, vbDirectory) = "" Then MkDir p
    End If
    OutputFolder = p
End Function

Private Function JsStr(ByVal s As String) As String
    s = Replace(s, "\", "\\")
    s = Replace(s, """", "\""")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    JsStr = """" & s & """"
End Function

Private Function JsNum(ByVal v As Variant) As String
    If IsError(v) Then
        JsNum = """"""
    ElseIf IsEmpty(v) Then
        JsNum = """"""
    ElseIf IsNumeric(v) And CStr(v) <> "" Then
        JsNum = Trim$(Str$(CDbl(v)))   ' Str() always uses a dot, whatever the regional settings
    Else
        JsNum = """"""
    End If
End Function

Private Sub WriteUtf8(ByVal path As String, ByVal text As String)
    ' Write to a temp file first, then swap it in, so the web page never reads a half-written file.
    Dim tmp As String, st As Object
    tmp = path & ".tmp"
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.WriteText text
    st.SaveToFile tmp, 2
    st.Close
    On Error Resume Next
    Kill path
    On Error GoTo 0
    Name tmp As path
End Sub
