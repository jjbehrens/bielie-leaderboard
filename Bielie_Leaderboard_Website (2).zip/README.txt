BIELIE LEADERBOARD 2026 - DAY 1 WEBSITE
=======================================

What's in this folder
  leaderboard.html       The website, opens on the DAY 1 boards (like the Share D1 tab).
  day2.html              The same website, opens on the DAY 2 boards (same layout as Day 1).
  overall.html           The same website, opens on the OVERALL boards (like the Display Overall tab).
  data.js                The scores (Day 1 + Day 2). The Excel macro overwrites this file.
  BielieWebExport.bas    The Excel macro module (local export + GitHub upload).
  upload-to-github\      The files that go online (index.html, day2.html, overall.html, data.js).

All pages have a DAY 1 / DAY 2 / OVERALL switch at the top, so any file can show all three.
Overall follows the Display Overall tab: one division per screen, Gross and Nett
side by side, 15 players per page (Division C: Points, 30 per page), short names
(e.g. "Marx C."), and a player only appears once BOTH rounds are entered.

How it works
  Excel --(every 10 s)--> data.js on your laptop --> projector screen (instant)
        --(when scores change, max once a minute)--> GitHub --> phones (~1-2 min)


PART 1 - PROJECTOR (same as before)
-----------------------------------
1. Put leaderboard.html, day2.html, overall.html and data.js in the SAME folder as the workbook
   (e.g. C:\Bielie\).
2. Workbook > Alt+F11 > File > Import File... > BielieWebExport.bas
   (If you imported the earlier version: right-click BielieWebExport in the
   left panel > Remove > No, then import this one.)
3. Save the workbook (.xlsm).


PART 2 - ONLINE LEADERBOARD ON GITHUB (one-time, ~10 minutes)
-------------------------------------------------------------
A. Create the site
   1. Sign up / sign in at https://github.com (free account is fine).
   2. Top right "+" > New repository.
        Repository name: bielie-leaderboard
        Public  (free GitHub Pages needs a public repository)
        Tick "Add a README file"  > Create repository.
   3. In the new repository: "Add file" > "Upload files". Drag in BOTH files
      from the upload-to-github folder (index.html, day2.html, overall.html, data.js) > Commit changes.
   4. Settings (tab) > Pages (left menu) > Build and deployment > Source:
      choose "GitHub Actions". In the suggestions, find "Static HTML" and click
      "Configure", then click "Commit changes..." > "Commit changes".
   5. Wait about 1 minute. Your leaderboard is now at
        https://jjbehrens.github.io/bielie-leaderboard/              (Day 1)
        https://jjbehrens.github.io/bielie-leaderboard/day2.html     (Day 2)
        https://jjbehrens.github.io/bielie-leaderboard/overall.html  (Overall)
      (Settings > Pages shows the exact link.) This is the link for WhatsApp.

B. Give Excel permission to upload scores
   1. GitHub: your photo (top right) > Settings > Developer settings (bottom of
      the left menu) > Personal access tokens > Fine-grained tokens >
      Generate new token.
        Token name: Bielie Excel
        Expiration: 30 days (or past the tournament date)
        Repository access: Only select repositories > bielie-leaderboard
        Permissions > Repository permissions > Contents: Read and write
      > Generate token, and copy it (starts with github_pat_...).
   2. In the workbook's folder, create a text file named  github-token.txt
      and paste the token as the only line. Save it.
      Do NOT send this file to anyone - it lets people change the website.
      (If the workbook is on OneDrive, put the file in Documents\BielieWebsite.)

C. Tell the macro your GitHub name
   1. Alt+F11 > open module BielieWebExport. At the top, change
        Public Const GITHUB_OWNER As String = "YOUR-GITHUB-USERNAME"
      to your GitHub user name, e.g. "jjbehrens". Save the workbook.
   2. Test: Alt+F8 > PushWebNow > Run. You should get "Uploaded to GitHub".
      Refresh the online link after a minute.


ON THE DAY
----------
1. Make sure the scoring laptop has internet (clubhouse Wi-Fi or a phone hotspot).
2. Alt+F8 > StartWebExport > Run. The status bar at the bottom of Excel shows
   the local time and "online: uploaded hh:mm:ss" (or what went wrong).
3. Open leaderboard.html (Day 1), day2.html (Day 2) or overall.html (Overall) on the projector
   laptop > Projector mode. It rotates through the mode you are in:
     Day 1/2:  Podium > A Gross > A Nett > B Gross > B Nett > C Points
     Overall:  Podium > Division A > Division B (page 1, 2, 3) > Division C
   Right arrow / space = next board, Esc = exit.
   For two screens on Day 2: day2.html on one, overall.html on the other.
4. Share the github.io link on WhatsApp. Phones refresh by themselves.
5. Finished: Alt+F8 > StopWebExport.

If the internet drops, the projector keeps working; the online board catches
up on the next upload once the connection is back.


TROUBLESHOOTING (status bar messages)
-------------------------------------
  no token ...         github-token.txt missing or in the wrong folder
  token rejected (401) token copied wrong or expired - make a new one
  not allowed (403)    token needs Contents: Read and write
  repo not found (404) GITHUB_OWNER / repo name wrong, or token not given this repo
  no internet ...      laptop is offline
